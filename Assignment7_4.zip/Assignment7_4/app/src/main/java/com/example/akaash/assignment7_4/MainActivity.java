package com.example.akaash.assignment7_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button btn_login;
    private EditText ed_username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login=(Button)findViewById(R.id.button);
        ed_username=(EditText)findViewById(R.id.editText);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String var_username;

                var_username=ed_username.getText().toString();
                Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                Bundle bundle=new Bundle();
                bundle.putString("Username",var_username);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
