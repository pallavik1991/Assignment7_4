package com.example.akaash.assignment7_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    private TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent=getIntent();
        Bundle b=intent.getExtras();

        txt=(TextView)findViewById(R.id.textView2);
        if(b!=null) {
            String varusername = b.getString("Username");
            txt.setText("Welcome "+varusername);
        }
    }
}
